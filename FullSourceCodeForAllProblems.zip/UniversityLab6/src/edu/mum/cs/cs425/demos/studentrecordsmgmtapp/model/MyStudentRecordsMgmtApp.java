package edu.mum.cs.cs425.demos.studentrecordsmgmtapp.model;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class MyStudentRecordsMgmtApp {

	public static void main(String[] args) {
		Student[] listOfStudents = { new Student("Dave", "110001", LocalDate.of(1951, 11, 18)),
				new Student("Anna", "110002", LocalDate.of(1990, 12, 7)),
				new Student("Erica", "110003", LocalDate.of(1974, 1, 31)),
				new Student("Carlos", "110004", LocalDate.of(2009, 8, 22)),
				new Student("Bob", "110005", LocalDate.of(1990, 3, 5)), };
//		printListOfStudents(listOfStudents);
//
//		List<Student> platinum = getListOfPlatinumAlumniStudents(listOfStudents);
//
//		platinum.sort((s1, s2) -> s2.getDateOfAdmission().compareTo(s1.getDateOfAdmission()));
//
//		platinum.forEach(s -> System.out.println("Name: " + s.getName() + "\nID: " + s.getStudentId()
//				+ "\nDate Of Admission: " + s.getDateOfAdmission() + "\n"));

		findSecondBiggest(new int[] { 1, 2, 3, 4, 5 });
		findSecondBiggest(new int[] { 19, 9, 11, 0, 12, 32, 21, 25 });
	}

	public static void printListOfStudents(Student[] listOfStudents) {

		Stream.of(listOfStudents).sorted((s1, s2) -> s1.getName().compareTo(s2.getName()))
				.forEach(s -> System.out.println("Name: " + s.getName() + "\nID: " + s.getStudentId()
						+ "\nDate Of Admission: " + s.getDateOfAdmission() + "\n"));
		;

	}

	public static List<Student> getListOfPlatinumAlumniStudents(Student[] listOfStudents) {

		return Stream.of(listOfStudents)
				.filter(s -> s.getDateOfAdmission().compareTo(LocalDate.now().minusYears(30)) <= 0)
				.collect(Collectors.toList());
	}

	public static void printHelloWorld(int[] arrOfIntegers) {

		for (int i : arrOfIntegers) {

			if (i % 5 == 0 && i % 7 == 0) {
				System.out.println("HelloWorld");
			} else {
				if (i % 5 == 0)
					System.out.println("Hello");
				else if (i % 7 == 0)
					System.out.println("World");
			}

		}

	}

	public static void findSecondBiggest(int[] arrOfIntegers) {
		int max = arrOfIntegers[0];

		// finding the max and inserting it at the beginning of the array

		for (int i = 1; i < arrOfIntegers.length; i++) {
			if (arrOfIntegers[i] > max) {

				max = arrOfIntegers[i];
				arrOfIntegers[i] = arrOfIntegers[0];
				arrOfIntegers[0] = max;

			}

		}

		int secondMax = arrOfIntegers[1];
		for (int i = 2; i < arrOfIntegers.length; i++) {

			if (arrOfIntegers[i] > secondMax) {

				secondMax = arrOfIntegers[i];
			}

		}
		System.out.println("Max:" + max + "\nSecond " + secondMax);
	}

}
